# QueryTuningAgent-Portable

AI SQL 쿼리 최적화 에이전트 - LLM과 MCP(Model Context Protocol) Tools를 활용한 자동 SQL 쿼리 튜닝 애플리케이션

## 기술 스택

| 분류 | 기술 |
|------|------|
| **Backend** | Python 3.12, Flask |
| **LLM** | OpenAI 호환 API (GPT-4) |
| **Database** | PostgreSQL, Oracle 지원 |
| **Frontend** | HTML/CSS/JS (단일 페이지 웹 UI) |
| **패키징** | Portable 배포판 (내장 Python 포함) |

## 아키텍처

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Web UI    │────▶│  AI Agent   │────▶│  LLM API    │
│  (Flask)    │     │  (Python)   │     │ (GPT-4)     │
└─────────────┘     └──────┬──────┘     └─────────────┘
                          │
                          ▼
                   ┌─────────────┐     ┌─────────────┐
                   │ MCP Server  │────▶│ PostgreSQL/ │
                   │  (Tools)    │     │   Oracle    │
                   └─────────────┘     └─────────────┘
```

## 주요 기능

1. **자동 쿼리 분석** - LLM이 테이블 스키마 자동 조회
2. **실행 계획 분석** - EXPLAIN/EXPLAIN PLAN으로 성능 분석
3. **인덱스 추천** - 쿼리 패턴에 맞는 최적 인덱스 제안
4. **쿼리 재작성** - 성능 향상을 위한 쿼리 재작성 제안
5. **반복 최적화** - 목표 성능(30% 개선)까지 자동 재시도
6. **플러그인 시스템** - 커스텀 MCP 도구 추가 가능

## 폴더 구조

```
QueryTuningAgent-Portable/
├── QueryTuningAgent.exe    # 실행 파일 (서버 시작)
├── main.py                 # 메인 엔트리포인트
├── config.py               # 설정 관리 (Pydantic)
├── config.json             # 저장된 설정
├── python/                 # 내장 Python 런타임
│
├── agent/                  # AI Agent
│   ├── agent.py           # 핵심 튜닝 로직
│   └── llm.py             # LLM API 클라이언트
│
├── mcp_server/             # MCP 서버
│   ├── server.py          # MCP 서버 메인
│   ├── db.py              # DB 연결 관리
│   ├── plugin_loader.py   # 플러그인 시스템
│   ├── tools/             # MCP Tools
│   │   ├── schema.py      # 스키마 조회
│   │   ├── explain.py     # 실행 계획 분석
│   │   ├── index.py       # 인덱스 관련
│   │   └── query.py       # 쿼리 실행/검증
│   └── plugins/           # 커스텀 플러그인
│       ├── csv_export.py
│       └── pdf_export.py
│
└── ui/                     # 웹 UI
    ├── app.py             # Flask 앱
    ├── templates/         # HTML
    └── static/            # CSS/JS
```

## MCP Tools (18개)

| 카테고리 | 도구 |
|----------|------|
| **스키마** | `get_all_tables`, `get_table_schema`, `get_table_indexes`, `get_table_statistics`, `extract_tables_from_query` |
| **실행계획** | `explain_query`, `explain_analyze_query`, `get_query_plan_summary`, `compare_query_plans`, `simulate_with_index_hint` |
| **인덱스** | `suggest_indexes`, `check_index_usage`, `get_unused_indexes` |
| **쿼리** | `execute_query`, `validate_query`, `rewrite_query_suggestions`, `get_row_count`, `get_table_size` |

## 실행 방법

### GUI 실행
```
QueryTuningAgent.exe 더블클릭
```

### CLI 실행
```bash
# 웹 서버 시작 (기본)
python main.py web

# CLI에서 직접 쿼리 튜닝
python main.py tune "SELECT * FROM users WHERE status = 'active'"

# DB 연결 테스트
python main.py test-db

# 사용 가능한 MCP 도구 목록
python main.py tools
```

브라우저에서 `http://localhost:5000` 접속

## 환경 설정

### 방법 1: .env 파일
`.env.example`을 `.env`로 복사 후 수정

```bash
# Database Configuration
DB_TYPE=postgres          # postgres 또는 oracle
DB_NAME=trading_bot
DB_USER=postgres
DB_PASSWORD=postgres
DB_HOST=localhost
DB_PORT=5432

# LLM API Configuration
LLM_API_URL=https://api.abclab.ktds.com/v1
LLM_API_KEY=              # API 키가 필요한 경우 입력
LLM_MODEL=gpt-4
LLM_MAX_TOKENS=4096
LLM_TEMPERATURE=0.1

# Agent Configuration
AGENT_MAX_ITERATIONS=10
AGENT_TARGET_COST_REDUCTION=0.3
```

### 방법 2: 웹 UI
실행 중 Settings 메뉴에서 직접 설정 변경 가능

## 웹 UI 사용 가이드

### 1. 쿼리 최적화
1. 좌측 텍스트 영역에 최적화할 SQL 쿼리 입력
2. "Tune Query" 버튼 클릭
3. AI가 자동으로:
   - 쿼리에서 테이블 추출
   - 각 테이블의 스키마 조회
   - 실행 계획 분석
   - 인덱스 추천
   - 최적화된 쿼리 제안

### 2. 설정 변경
우측 상단 "Settings" 버튼 클릭:
- **Database Configuration**: PostgreSQL/Oracle 연결 정보
- **LLM Configuration**: LLM API URL, 모델 설정

### 3. 추가 질문
쿼리 최적화 후 하단 입력창을 통해 추가 질문 가능:
- "이 쿼리에 적합한 인덱스를 더 자세히 설명해주세요"
- "JOIN 순서를 바꾸면 어떻게 될까요?"

## 플러그인 추가 방법

### 기본 도구 수정
`mcp_server/tools/` 폴더의 `.py` 파일 수정

### 커스텀 플러그인 추가
1. `mcp_server/plugins/` 폴더에 `.py` 파일 추가
2. UI에서 Settings > Reload Plugins 클릭

자세한 내용은 `PLUGIN_GUIDE.md` 참조

## API 엔드포인트

| Method | Endpoint | 설명 |
|--------|----------|------|
| GET | `/` | 메인 페이지 |
| GET | `/api/config` | 현재 설정 조회 |
| POST | `/api/config/db` | DB 설정 변경 |
| POST | `/api/config/llm` | LLM 설정 변경 |
| POST | `/api/db/test` | DB 연결 테스트 |
| GET | `/api/db/tables` | 테이블 목록 조회 |
| POST | `/api/tune` | 쿼리 최적화 시작 |
| GET | `/api/tune/stream/{id}` | 최적화 진행 상황 (SSE) |
| POST | `/api/chat` | 대화형 질문 |
| GET | `/api/tools` | 사용 가능한 도구 목록 |

## 최적화 워크플로우

AI Agent는 다음 단계로 쿼리를 최적화합니다:

1. **테이블 추출**: 쿼리에서 사용된 테이블 식별
2. **스키마 분석**: 각 테이블의 컬럼, 타입, 제약조건 조회
3. **실행 계획 분석**: EXPLAIN으로 현재 실행 계획 확인
4. **인덱스 검토**: 기존 인덱스와 사용 현황 확인
5. **쿼리 패턴 분석**: 안티패턴 및 개선점 식별
6. **최적화 제안**: 인덱스 추가, 쿼리 재작성 등 제안
7. **결과 비교**: 원본과 최적화된 쿼리의 실행 계획 비교
8. **반복**: 목표 개선율(기본 30%)에 도달할 때까지 반복

## 특징

- **포터블 배포**: Python 런타임 포함, 설치 불필요
- **이중 LLM**: 채팅용/튜닝용 LLM 분리 가능
- **플러그인 시스템**: 런타임에 도구 추가 가능
- **SSE 스트리밍**: 실시간 튜닝 진행 상황 표시
- **한글 최적화**: 시스템 프롬프트가 한글 응답 강제

## 문제 해결

### DB 연결 실패
- Settings에서 DB 정보 확인
- Host, Port가 올바른지 확인
- PostgreSQL/Oracle 서비스가 실행 중인지 확인
- 사용자 권한 확인

### LLM API 오류
- Settings에서 LLM 설정 확인
- API URL이 올바른지 확인
- API Key가 필요한 경우 입력
- 네트워크 연결 확인

## 라이선스

MIT License
